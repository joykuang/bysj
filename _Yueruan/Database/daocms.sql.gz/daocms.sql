-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `cms_class`;
CREATE TABLE `cms_class` (
  `class_id` int(8) NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `class_title` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '未命名' COMMENT '分类名称',
  `class_class_id` int(8) NOT NULL DEFAULT '0' COMMENT '分类分组id',
  `class_author_id` int(8) NOT NULL DEFAULT '0' COMMENT '分类创建者',
  `class_slug` char(255) COLLATE utf8_bin DEFAULT NULL COMMENT '分类自定义url后缀',
  `class_status` int(2) NOT NULL DEFAULT '0' COMMENT '分类状态',
  `class_excerpt` longtext COLLATE utf8_bin COMMENT '分类描述',
  `class_sort` int(8) NOT NULL DEFAULT '1' COMMENT '分类排序',
  `class_data` longtext COLLATE utf8_bin COMMENT '分类其他设置',
  `class_roles` longtext COLLATE utf8_bin COMMENT '分类权限设置',
  PRIMARY KEY (`class_id`),
  UNIQUE KEY `class_slug` (`class_slug`),
  KEY `class_title` (`class_title`),
  KEY `class_class_id` (`class_class_id`),
  KEY `class_author_id` (`class_author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


DROP TABLE IF EXISTS `cms_post`;
CREATE TABLE `cms_post` (
  `post_id` int(8) NOT NULL AUTO_INCREMENT COMMENT '博文id',
  `post_title` char(255) COLLATE utf8_bin NOT NULL DEFAULT '未命名' COMMENT '博文标题',
  `post_class_id` int(8) NOT NULL DEFAULT '0' COMMENT '博文分类id，为0时，表未分类',
  `post_author_id` int(8) NOT NULL COMMENT '博文作者id',
  `post_type_id` int(8) NOT NULL DEFAULT '1' COMMENT '默认文章模板类型',
  `post_slug` char(255) COLLATE utf8_bin DEFAULT NULL COMMENT '文章自定义url后缀',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '文章发布时间',
  `post_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '编辑文章时更新的时间',
  `post_content` longtext COLLATE utf8_bin COMMENT '博文内容',
  `post_excerpt` longtext COLLATE utf8_bin COMMENT '博文简介/梗概/说明/概要',
  `post_face` int(8) NOT NULL DEFAULT '0' COMMENT '博文缩略图/封面文件id',
  `post_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '博文发布的状态',
  `post_comment_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否允许评论',
  `post_comment_count` int(8) NOT NULL DEFAULT '0' COMMENT '评论计数',
  `post_data` longtext COLLATE utf8_bin COMMENT '额外设置，JSON Array',
  `post_roles` longtext COLLATE utf8_bin COMMENT '权限分配，普通一维纯数字数组',
  PRIMARY KEY (`post_id`),
  UNIQUE KEY `post_slug` (`post_slug`),
  KEY `post_title` (`post_title`),
  KEY `post_class_id` (`post_class_id`),
  KEY `post_author_id` (`post_author_id`),
  KEY `post_type_id` (`post_type_id`),
  KEY `post_date` (`post_date`),
  KEY `post_update` (`post_update`),
  KEY `post_face` (`post_face`),
  KEY `post_comment_count` (`post_comment_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cms_post` (`post_id`, `post_title`, `post_class_id`, `post_author_id`, `post_type_id`, `post_slug`, `post_date`, `post_update`, `post_content`, `post_excerpt`, `post_face`, `post_status`, `post_comment_status`, `post_comment_count`, `post_data`, `post_roles`) VALUES
(1,	'未命名',	0,	1,	1,	NULL,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'未命名未命名未命名',	'未命名未命名',	0,	0,	0,	0,	NULL,	NULL);

DROP TABLE IF EXISTS `cms_user`;
CREATE TABLE `cms_user` (
  `user_id` int(8) NOT NULL AUTO_INCREMENT,
  `user_account` char(255) COLLATE utf8_bin DEFAULT '',
  `user_nickname` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_realname` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_email` char(255) COLLATE utf8_bin NOT NULL,
  `user_password` char(255) COLLATE utf8_bin NOT NULL,
  `user_slug` char(1) COLLATE utf8_bin DEFAULT NULL,
  `user_group_id` int(8) NOT NULL DEFAULT '2',
  `user_status` int(8) NOT NULL DEFAULT '0',
  `user_avatar` int(8) NOT NULL DEFAULT '0',
  `user_register` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_login_ip` char(255) COLLATE utf8_bin NOT NULL DEFAULT '0.0.0.0',
  `user_activation` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_data` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_roles` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_telephone` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_introduction` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_qq` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_weixin` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_weibo` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_blog` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_birth` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_hometown` char(255) COLLATE utf8_bin DEFAULT NULL,
  `user_address` char(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_email` (`user_email`),
  UNIQUE KEY `user_account` (`user_account`),
  UNIQUE KEY `user_nickname` (`user_nickname`),
  UNIQUE KEY `user_slug` (`user_slug`),
  KEY `user_group_id` (`user_group_id`),
  KEY `user_register` (`user_register`),
  KEY `user_login` (`user_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cms_user` (`user_id`, `user_account`, `user_nickname`, `user_realname`, `user_email`, `user_password`, `user_slug`, `user_group_id`, `user_status`, `user_avatar`, `user_register`, `user_access`, `user_login`, `user_login_ip`, `user_activation`, `user_data`, `user_roles`, `user_telephone`, `user_introduction`, `user_qq`, `user_weixin`, `user_weibo`, `user_blog`, `user_birth`, `user_hometown`, `user_address`) VALUES
(1,	'joy',	'九月香橙',	'Joy Kuang',	'q-cute@163.com',	'',	NULL,	1,	0,	0,	'2015-03-11 21:44:31',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'0.0.0.0',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL);

-- 2015-03-11 15:04:57
